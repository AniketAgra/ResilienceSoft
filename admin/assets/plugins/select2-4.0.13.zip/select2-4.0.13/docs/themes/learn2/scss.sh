#!/bin/sh
scss --watch scss:css-compiled
